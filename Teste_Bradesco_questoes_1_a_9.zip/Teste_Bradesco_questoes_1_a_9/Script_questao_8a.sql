-- SELECIONE AS PARTES RELEVANTES DO SCRIPT PARA REALIZAR AS A��ES

-- Sele��o das tabelas

Select
	NomeCidade
	, avg(Nota) AS [Nota m�dia]
	, max (Nota) as [Maior Nota]
	, min(Nota) as [Menor Nota]
from Aplicante 
group by NomeCidade
having count(*) > 1

--select * from Aplicante