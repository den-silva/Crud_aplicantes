---- SELECIONE AS PARTES RELEVANTES DO SCRIPT PARA REALIZAR AS A��ES

---- Cria��o e uso do banco de dados

--create database bancoTesteBradesco
--use bancoTesteBradesco

---------------------------------------------------------------------------------------------

---- Cria��o das tabelas 

--CREATE TABLE Cidade (
--    Id INT PRIMARY KEY,
--    Nome VARCHAR(255) NOT NULL,
--    Estado VARCHAR(255) NOT NULL
--);

--CREATE TABLE Aplicante (
--    Id INT PRIMARY KEY,
--    Nome VARCHAR(255) NOT NULL,
--    IdCidade INT,
--	NomeCidade VARCHAR(255),
--    Nota DECIMAL(5, 1),

--);

---------------------------------------------------------------------------------------------

---- Carga das tabelas

--INSERT INTO Cidade (Id, Nome, Estado)
--VALUES
--    (1,'Rio de Janeiro', 'RJ'),
--    (2,'S�o Paulo', 'SP'),
--    (3,'Florianopolis', 'SC');

--INSERT INTO Aplicante (Id, Nome, NomeCidade, Nota)
--VALUES
--    (3, 'Felipe'	,'S�o Paulo'		, 0.7),
--    (9, 'Ricardo'	,'Santa Catarina'	, 2.7),
--    (6, 'Leticia'	,'S�o Paulo'		, 3.3),
--    (10, 'Viviane'	,'Fortaleza'		, 3.8),
--    (1, 'Alvaro'	,'Rio de Janeiro'	, 5.1),
--    (2, 'Caio'		,'Rio de Janeiro'	, 6.7),
--    (4, 'Joana'		,'Rio de Janeiro'	, 7.3),
--    (8, 'Maria'		,'Fortaleza'		, 7.3),
--    (5, 'Jose'		,'S�o Paulo'		, 10),
--    (7, 'Marcia'	,'Florianopolis'	, 10);

---------------------------------------------------------------------------------------------

---- Sele��o das tabelas

--Select ap.Nome, ap.NomeCidade, isnull(c.Estado, 'N�o identificado') as Estado, ap.Nota as Nota
--from Aplicante ap
--left join Cidade c on ap.NomeCidade = c.Nome

--order by 4 
